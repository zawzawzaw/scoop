		<footer id="footer-wrapper" class="fixed-footer"><!-- container-fluid -->
			<div class="v-align-table">
				<div class="v-align-table-cell">
					<div class="copyright">
						<p>© 2016 Scoop Therapy. All Rights Reserved.</p>
						<p>No part of this website, designs, layouts or any of its contents may be reproduced, copied, modified or adapted, without the prior written consent of Scoop Therapy. </p>
					</div>
					<ul>
						<li><a href="https://twitter.com/hashtag/scoop_therapy?src=hash" class="twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="https://www.instagram.com/explore/tags/scooptherapy/" class="instagram"><i class="fa fa-instagram"></i></a></li>						
					</ul>
				</div>
			</div>							
		</footer>		

	</div>

	<?php Loader::element('footer_required') ?>
		
</body>
</html>