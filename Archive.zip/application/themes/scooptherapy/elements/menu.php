<div id="menu-logo-wrapper" class="animated slideInDown">
	
	<div class="main-menu">		
		<div class="pull-left">
			<div class="toggle-menu-container">					
				<div class="toggle-menu">
					<a href="javascript:void(0)"> 
						<span class="nav-bar"></span> 
						<span class="nav-bar"></span> 
						<span class="nav-bar"></span> 
					</a> 
				</div>
			</div>
			<div class="main-nav-wrapper">
				<ul class="main-nav">
					<li><a href="<?php echo View::url('/'); ?>#about">About</a></li>
					<li><a href="<?php echo View::url('/'); ?>#flavours">Flavours</a></li>
					<li><a href="<?php echo View::url('/'); ?>#news">News</a></li>
					<li><a href="<?php echo View::url('/'); ?>#locate">Locate</a></li>
					<li><a href="<?php echo View::url('/'); ?>#wholesale">Wholesale</a></li>
				</ul>				
			</div>
		</div>
		<a href="index.html" class="logo pull-right"><img src="<?= $view->getThemePath() ?>/images/logos/main-logo.png" alt=""></a>				
	</div>	

</div>